/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000003942206988_2799536233_init();
    unisims_ver_m_00000000003927721830_1593237687_init();
    unisims_ver_m_00000000003317509437_1759035934_init();
    work_m_00000000002175384291_3824692077_init();
    work_m_00000000003365508363_1871713313_init();
    work_m_00000000002760752048_2725559894_init();
    work_m_00000000003448746066_2017484987_init();
    work_m_00000000004186355503_2243755181_init();
    work_m_00000000001044125441_0593818359_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000001044125441_0593818359");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
